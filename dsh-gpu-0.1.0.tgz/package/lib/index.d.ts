import { Context } from "@deepseek-ai/cordis";
import z from "@deepseek-ai/schemastery";

//#region src/nvidia.d.ts

/**
 * nvidia-smi querying and parsing: one snapshot of every GPU on the host.
 *
 * Pure parsing lives here so tests can feed recorded output; the executor
 * injection lives in the plugin entry. Queries use CSV format for
 * machine-parseability and are resilient to unit suffixes (MiB/GiB).
 *
 * @module dsh-gpu/nvidia
 */
/** One GPU device snapshot. */
interface GpuDevice {
  /** Physical index as in CUDA ordering. */
  index: number;
  /** Device name, e.g. 'Tesla V100-SXM2-32GB'. */
  name: string;
  /** Total device memory in MiB. */
  memoryTotalMiB: number;
  /** Memory currently in use, MiB. */
  memoryUsedMiB: number;
  /** SM utilization percent, 0-100. */
  utilizationPct: number;
  /** Temperature in Celsius. */
  temperatureC: number;
}
/** Whole-host snapshot. */
interface GpuSnapshot {
  devices: GpuDevice[];
  /** nvidia-smi string when present, e.g. '550.54.15'. */
  driverVersion?: string;
  /** CUDA version string when present, e.g. '12.4'. */
  cudaVersion?: string;
  /** Wall-clock time of the snapshot. */
  sampledAt: number;
}
/** A device is free when both memory and SM utilization are low. */
//#endregion
//#region src/index.d.ts
sideEffect();
/** Cordis plugin name used by loader diagnostics. */
declare const name = "gpu";
/** Required services: tool registry, shell executor, system prompt, agent registry. */
declare const inject: string[];
interface Config {
  /** Inject the one-line GPU summary into eligible steps. Default true. */
  stepContext?: boolean;
  /** Minimum spacing between injected GPU snapshots, ms. Default 60_000. */
  refreshIntervalMs?: number;
  /** Query timeout for nvidia-smi, ms. Default 10_000. */
  queryTimeoutMs?: number;
  /** Consider a GPU busy above this memory-used percent. Default 80. */
  busyMemoryPct?: number;
  /** Consider a GPU busy above this SM utilization percent. Default 50. */
  busyUtilPct?: number;
}
declare const Config: z<Config>;
/** Pick GPUs: explicit index, or the N freest devices. Exported for tests. */
declare function pickGpus(snapshot: GpuSnapshot, args: {
  gpuIndex?: number;
  count?: number;
}, busyMemoryPct: number, busyUtilPct: number): {
  indices: number[];
  note: string;
};
declare function apply(ctx: Context, config?: Config): void;
//#endregion
export { Config, apply, inject, name, pickGpus };